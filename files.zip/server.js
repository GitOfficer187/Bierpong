const http = require('http'), fs = require('fs'), path = require('path'), os = require('os');
const { WebSocketServer } = require('ws');
const PORT = process.env.PORT || 3000;
const page = fs.readFileSync(path.join(__dirname, 'index.html'));
let state = null; // gemeinsamer Spielstand (liegt nur im Arbeitsspeicher)

const server = http.createServer((req, res) => {
  if (req.url === '/health') { res.end('ok'); return; }
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
  res.end(page);
});
const wss = new WebSocketServer({ server });

function send(ws, force) {
  if (ws.readyState === 1) ws.send(JSON.stringify({ t: 'state', s: state, force: !!force }));
}
function broadcast(except) {
  wss.clients.forEach(c => { if (c !== except) send(c, false); });
}

wss.on('connection', ws => {
  ws.isAlive = true;
  ws.on('pong', () => { ws.isAlive = true; });
  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    if (!m || !m.s) return; // z. B. Heartbeat
    if (m.t === 'hello') {
      if (!state) { state = m.s; broadcast(ws); } else send(ws, true);
    } else if (m.t === 'state') {
      if (!state || (m.s.v || 0) >= (state.v || 0)) { state = m.s; broadcast(ws); }
    }
  });
});

setInterval(() => wss.clients.forEach(c => {
  if (!c.isAlive) return c.terminate();
  c.isAlive = false; c.ping();
}), 25000);

server.listen(PORT, '0.0.0.0', () => {
  console.log('Bierpong-Turnier läuft auf Port ' + PORT);
  Object.values(os.networkInterfaces()).flat()
    .filter(i => i && i.family === 'IPv4' && !i.internal)
    .forEach(i => console.log('Im WLAN erreichbar unter: http://' + i.address + ':' + PORT));
});
